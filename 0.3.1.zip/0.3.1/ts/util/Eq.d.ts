export interface Eq<K> {
    eq(that: K): boolean;
}

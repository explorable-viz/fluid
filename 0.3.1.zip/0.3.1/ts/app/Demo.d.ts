import "../BaseTypes";
import "../Graphics";
import "../app/GraphicsRenderer";
export declare function initialise(): void;
